import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChannelService {

  constructor() {
  }

  channel = [
    {
      name: "ZEE",
      value: 10,
    },
    {
      name: "SONY",
      value: 15,
    },
    {
      name: "StarPlus",
      value: 20,
    }, {
      name: "Discovery",
      value: 10,
    }, {
      name: "NatGeo",
      value: 20,
    }
  ];

  getchannel(){
    return this.channel;
  }

  spserv = [
    {
      type: "LearnEnglish",
      value: 200
    },
    {
      type: "CookingService",
      value: 100
    }
  ];
getspserv(){
  return this.spserv;
}
  pack = [
    {
      name: "Silver",
      channels: ["zee", "sony", "Star plus"],
      value: 50
    },
    {
      name: "Gold",
      channels: ["zee", "sony", "Star plus", "NatGeo", "dicovery"],
      value: 100
    }
  ]
  getpack(){
    return this.pack;
  }
}
