import { Component, OnInit } from '@angular/core';
import { ChannelService } from '../channel.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  channelarray = [];
  spserveobj = [];
  packobj = [];
  constructor(private service: ChannelService) { }

  ngOnInit() {
    // this.channelarray=this.service.channel;
    this.channelarray = this.service.getchannel();
    this.packobj = this.service.getpack();
    this.spserveobj = this.service.getspserv();

  }

  curbalence: number = 100;
  rechamt: number;
  msg: String;
  flag1: boolean = true;
  flag2: boolean = true;
  flag3: boolean = true;
  flag4: boolean = true;
  flag5: boolean = true;
  flag6: boolean = true;
  flag7: boolean = true;
  flag8: boolean = true;
  onclick1(event) {
    this.flag1 = false;

  }

  onclick2(event) {
    this.flag1 = true;
    this.flag2 = false;
  }
  recharge(amount) {

    this.rechamt = +amount.value;
    this.curbalence = this.curbalence + this.rechamt;
    this.msg = "recharge done successfully. balence is " + this.curbalence + ".";
    alert(this.msg);

  }
  onclick3(event) {
    this.flag3 = false;

  }

  onclick4(event) {
    this.flag4 = false;
  }
  packType: String;
  msg1: String;
  msg2: string;
  msg3: String;
  msg4: String;
  msg5: String;
  msg6: String;
  msg7: String; msg8: String; msg9: String;
  discount: number = 0;
  final_price: number;
  base_pack: String;
  Subscribe(mypack, mymonth) {
    this.packType = mypack.value;
    if (this.packType == 'G' && mymonth.value > 0) {
      this.base_pack = this.packobj[1].name;
      this.msg1 = "You have successfully subscribed the following packs-" + this.packobj[1].name;
      this.msg2 = "Monthly price:" + this.packobj[1].value + " Rs.";
      this.msg3 = "No of months:" + mymonth.value;
      this.msg4 = "Subscription Amount:" + (mymonth.value) * this.packobj[1].value + " Rs";
      if (mymonth.value >= 3) {
        this.discount = ((mymonth.value) * this.packobj[1].value) * 0.10;
        this.msg5 = "Discount applied:" + this.discount + " Rs.";
      }
      this.final_price = ((mymonth.value) * this.packobj[1].value) - this.discount;
      this.msg6 = "Final Price after discount:" + this.final_price + " Rs.";
      this.curbalence = this.curbalence - this.final_price;
      this.msg7 = "Account balance:" + this.curbalence + " Rs.";
      this.msg8 = "Email notification sent successfully";
      this.msg9 = "SMS notification sent successfully";

    }
    else if (this.packType == 'S' && mymonth.value > 0) {
      this.base_pack = this.packobj[0].name;
      this.msg1 = "You have successfully subscribed the following packs-" + this.packobj[0].name;
      this.msg2 = "Monthly price:" + this.packobj[0].value + " Rs.";
      this.msg3 = "No of months:" + mymonth.value;
      this.msg4 = "Subscription Amount:" + (mymonth.value) * this.packobj[0].value + " Rs.";
      if (mymonth.value >= 3) {
        this.discount = ((mymonth.value) * this.packobj[0].value) * 0.10;
        this.msg5 = "Discount applied:" + this.discount + " Rs.";
      }
      this.final_price = ((mymonth.value) * this.packobj[0].value) - this.discount;
      this.msg6 = "Final Price after discount:" + this.final_price + " Rs.";
      this.curbalence = this.curbalence - this.final_price;
      this.msg7 = "Account balance:" + this.curbalence + " Rs.";
      this.msg8 = "Email notification sent successfully";
      this.msg9 = "SMS notification sent successfully";
    }
  }

  onclick5(event) {
    this.flag5 = false;
  }
  msg10: String;
  input_ch: String;
  input: String[];
  count: number;
  addchannel(myaddon) {
    this.input_ch = myaddon.value;
    this.input = this.input_ch.split(",");
    for (let i = 0; i < this.input.length; i++)
     {
      for (let j = 0; j < this.channelarray.length; j++)
       {
        if (this.input[i] == this.channelarray[j].name)
         {
          // console.log(this.input.length);
          this.curbalence = this.curbalence - this.channelarray[i].value;
          this.msg7 = "Account balance:" + this.curbalence + " Rs.";
          this.base_pack = this.base_pack + "+" + this.channelarray[j].name;
          this.count = this.count + 1;
          this.msg10 = "Channels added successfully.";
        }
      }
      
    }
    
  }
  msg11: String;
  onclick6(event) {
    this.flag6 = false;
  }

  current_service: String = "";
  addervice(myservice) {

    for (let i = 0; i < this.spserveobj.length; i++) {
      if (this.spserveobj[i].type == myservice.value) {
        this.current_service = this.spserveobj[i].type;
        this.msg11 = "Service Subscribed successfully.";
        this.curbalence = this.curbalence - this.spserveobj[i].value;
        this.msg7 = "Account balance:" + this.curbalence + " Rs.";
        this.msg8 = "Email notification sent successfully";
        this.msg9 = "SMS notification sent successfully";

      }
    }
  }
  msg12: String;
  msg13: String;

  onclick7(event) {
    this.flag7 = false;
    this.msg12 = "Currently subscribed packs and channels:" + this.base_pack;

    this.msg13 = "Currently subscribed services:" + this.current_service;
  }
  msg14: String;
  msg15: String;
  Email: String;
  Phone: number;
  onclick8(event) {
    this.flag8 = false;
    this.msg14 = "Update email and phone number for notifications";
  }
  submit(email, phone) {
    this.Email = email.value;
    this.Phone = +phone.value;
    this.msg15 = "Email and Phone updated successfully";
  }
  onclick9(event) {
    this.flag1 = true;
    this.flag2 = true;
    this.flag3 = this.flag4 = this.flag5 = this.flag6 = this.flag7 = this.flag8 = true;
    alert("Thank for Using Sat TV")
  }
}
